
from kivy.lang import Builder
from kivy.uix.screenmanager import ScreenManager, Screen
from kivy.core.window import Window
from kivymd.app import MDApp
from kivymd.uix.button import MDFlatButton
from kivymd.uix.dialog import MDDialog
import random

Window.size = (360, 640)

class MenuScreen(Screen):
    pass

class MemoryScreen(Screen):
    def on_enter(self):
        self.sequence = []
        self.user_sequence = []
        self.score = 0
        self.ids.memory_label.text = "Watch the sequence!"
        self.generate_sequence()

    def generate_sequence(self):
        self.sequence.append(random.randint(1, 4))
        self.show_sequence()

    def show_sequence(self):
        self.ids.memory_label.text = "Sequence: " + " ".join(map(str, self.sequence))

    def check_input(self, value):
        self.user_sequence.append(int(value))
        if self.user_sequence == self.sequence[:len(self.user_sequence)]:
            if len(self.user_sequence) == len(self.sequence):
                self.score += 1
                self.user_sequence = []
                self.generate_sequence()
        else:
            self.ids.memory_label.text = f"Game Over! Score: {self.score}"
            self.sequence = []
            self.user_sequence = []
            self.score = 0

class MathScreen(Screen):
    def on_enter(self):
        self.score = 0
        self.next_question()

    def next_question(self):
        self.a = random.randint(1, 20)
        self.b = random.randint(1, 20)
        self.answer = self.a + self.b
        self.ids.math_label.text = f"Solve: {self.a} + {self.b}"

    def check_answer(self, value):
        if value.isdigit() and int(value) == self.answer:
            self.score += 1
            self.ids.math_label.text = f"Correct! Score: {self.score}"
        else:
            self.ids.math_label.text = f"Wrong! Score: {self.score}"
        self.next_question()

sm = ScreenManager()
sm.add_widget(MenuScreen(name='menu'))
sm.add_widget(MemoryScreen(name='memory'))
sm.add_widget(MathScreen(name='math'))

class MindMatrixApp(MDApp):
    dialog = None

    def build(self):
        return Builder.load_file("mindmatrix.kv")

    def show_about(self):
        if not self.dialog:
            self.dialog = MDDialog(
                title="About MindMatrix",
                text="MindMatrix - a logic, memory, and math challenge game by Subhash Saran.",
                buttons=[MDFlatButton(text="CLOSE", on_release=self.close_dialog)],
            )
        self.dialog.open()

    def close_dialog(self, obj):
        self.dialog.dismiss()

if __name__ == "__main__":
    MindMatrixApp().run()
